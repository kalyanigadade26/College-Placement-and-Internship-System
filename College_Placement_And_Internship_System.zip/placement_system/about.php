<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>About Us</title>
<link rel="stylesheet" href="css/style.css">
</head>

<body>

<header class="navbar">
    <div class="logo">🎓 College Placement and Internship System</div>

    <nav class="nav-links">
        <a href="/placement_system/index.php">Home</a>
        <a href="/placement_system/about.php" class="active">About Us</a>
        <a href="/placement_system/contact.php">Contact Us</a>
        <a href="/placement_system/feedback.php">Feedback</a> <!-- ✅ ADDED -->

        <?php if(isset($_SESSION['user'])) { ?>

            <?php if($_SESSION['role'] == "student") { ?>
                <a href="/placement_system/student/student_dashboard.php" class="btn">Dashboard</a>
            <?php } elseif($_SESSION['role'] == "admin") { ?>
                <a href="/placement_system/admin/admin_dashboard.php" class="btn">Dashboard</a>
            <?php } elseif($_SESSION['role'] == "company") { ?>
                <a href="/placement_system/company/company_dashboard.php" class="btn">Dashboard</a>
            <?php } ?>

            <a href="/placement_system/logout.php" class="btn">Logout</a>

        <?php } else { ?>
            <a href="/placement_system/login.php" class="btn">Login</a>
            <a href="/placement_system/register.php" class="btn">Register</a>
        <?php } ?>
    </nav>
</header>

<!-- ABOUT HERO -->
<section class="about-hero">
    <div class="overlay"></div>

    <div class="hero-content">
        <h1>About Our Placement System</h1>
        <p>Connecting Students With Opportunities</p>
    </div>
</section>

<!-- ABOUT CONTENT -->
<section class="about-section">
    <div class="about-container">

        <div class="about-card">
            <h2>🎯 Our Mission</h2>
            <p>Provide a smooth platform connecting students and companies.</p>
        </div>

        <div class="about-card">
            <h2>🚀 What We Offer</h2>
            <p>✔ Student Registration</p>
            <p>✔ Job Posting</p>
            <p>✔ Application Tracking</p>
            <p>✔ Admin Monitoring</p>
        </div>

        <div class="about-card">
            <h2>👩‍💻 Who Can Use</h2>
            <p>Students, Companies and College Administrators.</p>
        </div>

    </div>
</section>

</body>
</html>