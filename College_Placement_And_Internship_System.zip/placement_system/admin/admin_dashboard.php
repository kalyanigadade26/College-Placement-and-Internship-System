<?php
session_start();

// Protect page for admin only
if(!isset($_SESSION['user']) || $_SESSION['role'] != "admin"){
    header("Location: /placement_system/login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Admin Dashboard</title>

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:Arial, sans-serif;
}

/* BODY */
body{
    background:linear-gradient(135deg,#eef2ff,#e0e7ff);
    min-height:100vh;
}

/* NAVBAR */
.navbar{
    display:flex;
    justify-content:space-between;
    align-items:center;
    padding:15px 40px;
    background:#111;
    color:#fff;
}

.nav-links a{
    color:#fff;
    margin-left:20px;
    text-decoration:none;
    font-size:16px;
}

.nav-links .btn{
    background:#fff;
    color:#000 !important;
    padding:6px 12px;
    border-radius:5px;
    font-size:16px;
}

/* CONTAINER */
.container{
    max-width:1200px;
    margin:50px auto;
    text-align:center;
}

/* HEADER */
.header{
    margin-bottom:50px;
}

.header h1{
    font-size:32px;
}

.header p{
    color:#555;
    font-size:17px;
    margin-top:10px;
}

/* FLEX ROWS */
.row, .row-center{
    display:flex;
    justify-content:center;
    flex-wrap: wrap;
    gap:35px;
    margin-bottom:40px;
}

/* CARD */
.card{
    background:#fff;
    padding:30px 25px;
    border-radius:12px;
    box-shadow:0 6px 18px rgba(0,0,0,0.12);
    text-align:center;
    transition:0.3s;
    width:240px;
}

.card:hover{
    transform:translateY(-6px);
}

/* TITLE */
.card h3{
    margin-bottom:12px;
    font-size:20px;
}

/* TEXT */
.card p{
    color:#666;
    margin-bottom:20px;
    font-size:15px;
}

/* BUTTON */
.card a{
    display:inline-block;
    padding:10px 18px;
    background:#111;
    color:#fff;
    text-decoration:none;
    border-radius:6px;
    font-size:15px;
}
</style>
</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
    <div>🛡️ Admin Panel</div>
    <div class="nav-links">
        <a href="/placement_system/index.php">Home</a>
        <a href="/placement_system/about.php">About</a>
        <a href="/placement_system/contact.php">Contact</a>
        <a href="/placement_system/feedback.php">Feedback</a> <!-- ✅ ADDED -->
        <a href="/placement_system/admin/admin_dashboard.php">Dashboard</a>
        <a href="/placement_system/logout.php" class="btn">Logout</a>
    </div>
</div>

<!-- DASHBOARD -->
<div class="container">

<div class="header">
    <h1>Welcome, <?php echo $_SESSION['user']; ?> 👋</h1>
    <p>Manage students, companies, jobs, applications, and approve companies</p>
</div>

<!-- FIRST ROW -->
<div class="row">
    <div class="card">
        <h3>Manage Students</h3>
        <p>View, edit, or delete student accounts</p>
        <a href="/placement_system/admin/manage_students.php">Manage Students</a>
    </div>

    <div class="card">
        <h3>Manage Companies</h3>
        <p>View, edit, or delete company accounts</p>
        <a href="/placement_system/admin/manage_companies.php">Manage Companies</a>
    </div>

    <div class="card">
        <h3>Manage Job Postings</h3>
        <p>Edit or remove job postings from all companies</p>
        <a href="/placement_system/admin/manage_jobs.php">Manage Jobs</a>
    </div>
</div>

<!-- SECOND ROW CENTERED -->
<div class="row-center">
    <div class="card">
        <h3>Applications</h3>
        <p>View all student applications for jobs and internships</p>
        <a href="/placement_system/admin/view_applications_admin.php">View Applications</a>
    </div>

    <div class="card">
        <h3>Approve Companies</h3>
        <p>Approve or reject new company registrations</p>
        <a href="/placement_system/admin/approve_companies.php">Approve Companies</a>
    </div>
</div>

</div>

</body>
</html>