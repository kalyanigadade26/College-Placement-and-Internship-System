<?php
session_start();
include("../db.php");

// Protect page
if (!isset($_SESSION['user']) || $_SESSION['role'] != "admin") {
    header("Location: ../login.php");
    exit();
}

// Session storage (temporary approval system)
if (!isset($_SESSION['approved_companies'])) {
    $_SESSION['approved_companies'] = [];
}

// Approve company
if (isset($_GET['approve'])) {
    $id = (int)$_GET['approve'];
    $_SESSION['approved_companies'][$id] = true;

    header("Location: approve_companies.php?msg=approved");
    exit();
}

// Delete company
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $conn->exec("DELETE FROM users WHERE id=$id AND role='company'");

    header("Location: approve_companies.php?msg=deleted");
    exit();
}

// Fetch companies
$query = "SELECT * FROM users WHERE role='company' ORDER BY id DESC";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html>
<head>
<title>Approve Companies</title>

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Segoe UI', sans-serif;
}

body{
    background:linear-gradient(135deg,#eef2ff,#e0e7ff);
}

/* NAVBAR */
.navbar{
    display:flex;
    justify-content:space-between;
    padding:18px 50px;
    background:#111;
    color:#fff;
}

.nav-links a{
    color:#fff;
    margin-left:25px;
    text-decoration:none;
}

.nav-links .btn{
    background:#fff;
    color:#000 !important;
    padding:6px 12px;
    border-radius:6px;
}

/* CONTAINER */
.container{
    max-width:1000px;
    margin:60px auto;
}

/* HEADER */
.header{
    text-align:center;
    margin-bottom:30px;
}

.header h1{
    font-size:30px;
}

.header p{
    color:#555;
}

/* ALERT */
.alert{
    text-align:center;
    padding:12px;
    border-radius:8px;
    margin-bottom:20px;
    font-weight:500;
}

.success{
    background:#dcfce7;
    color:#166534;
}

.error{
    background:#fee2e2;
    color:#991b1b;
}

/* TABLE BOX */
.table-box{
    background:#fff;
    border-radius:12px;
    box-shadow:0 10px 25px rgba(0,0,0,0.08);
    overflow:hidden;
}

/* TABLE */
table{
    width:100%;
    border-collapse:collapse;
    table-layout:fixed;
}

th, td{
    padding:16px 20px;
    vertical-align:middle;
    white-space:nowrap;
}

th{
    background:#111;
    color:#fff;
    font-weight:600;
    text-align:left;
}

td{
    color:#333;
    text-align:left;
}

tr{
    border-bottom:1px solid #eee;
}

tr:hover{
    background:#f8fafc;
}

/* COLUMN ALIGNMENT (FIXED) */
th:nth-child(1),
td:nth-child(1){
    text-align:center;
    width:80px;
}

th:nth-child(4),
td:nth-child(4){
    text-align:center;
    width:140px;
}

th:nth-child(5),
td:nth-child(5){
    text-align:center;
    width:150px;
}

/* BUTTONS */
.btn-action{
    padding:6px 12px;
    border-radius:6px;
    text-decoration:none;
    font-size:14px;
    margin-right:5px;
    color:#fff;
}

.approve{
    background:#16a34a;
}

.delete{
    background:#dc2626;
}

/* STATUS BADGE */
.badge{
    padding:5px 12px;
    border-radius:20px;
    font-size:13px;
    font-weight:500;
}

.badge-approved{
    background:#d1fae5;
    color:#065f46;
}

.pending{
    color:#6b7280;
}
</style>
</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
    <div>🛡️ Admin Panel</div>
    <div class="nav-links">
        <a href="admin_dashboard.php">Dashboard</a>
        <a href="#">Approve Companies</a>
        <a href="../logout.php" class="btn">Logout</a>
    </div>
</div>

<!-- CONTENT -->
<div class="container">

    <div class="header">
        <h1>Company Approvals</h1>
        <p>Approve or remove registered companies</p>
    </div>

    <!-- ALERTS -->
    <?php if (isset($_GET['msg']) && $_GET['msg'] == 'approved') { ?>
        <div class="alert success">✅ Company approved successfully</div>
    <?php } ?>

    <?php if (isset($_GET['msg']) && $_GET['msg'] == 'deleted') { ?>
        <div class="alert error">❌ Company deleted</div>
    <?php } ?>

    <div class="table-box">

        <table>
            <tr>
                <th>ID</th>
                <th>Company Name</th>
                <th>Email</th>
                <th>Status</th>
                <th>Action</th>
            </tr>

            <?php while ($row = $result->fetchArray(SQLITE3_ASSOC)) { ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>

                    <td><?php echo htmlspecialchars($row['name']); ?></td>

                    <td><?php echo htmlspecialchars($row['email']); ?></td>

                    <td>
                        <?php if (isset($_SESSION['approved_companies'][$row['id']])) { ?>
                            <span class="badge badge-approved">Approved</span>
                        <?php } else { ?>
                            <span class="pending">Pending</span>
                        <?php } ?>
                    </td>

                    <td>
                        <?php if (!isset($_SESSION['approved_companies'][$row['id']])) { ?>
                            <a class="btn-action approve"
                               href="approve_companies.php?approve=<?php echo $row['id']; ?>">
                               Approve
                            </a>
                        <?php } ?>

                        <a class="btn-action delete"
                           href="approve_companies.php?delete=<?php echo $row['id']; ?>"
                           onclick="return confirm('Delete this company?');">
                           Delete
                        </a>
                    </td>
                </tr>
            <?php } ?>

        </table>

    </div>

</div>

</body>
</html>