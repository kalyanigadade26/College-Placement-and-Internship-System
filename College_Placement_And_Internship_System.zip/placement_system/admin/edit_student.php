<?php
session_start();
include("../db.php");

// Protect page for admin only
if(!isset($_SESSION['user']) || $_SESSION['role'] != "admin"){
    header("Location: ../login.php");
    exit();
}

// Get student ID
if(!isset($_GET['id'])){
    header("Location: manage_students.php");
    exit();
}

$id = (int)$_GET['id'];

// Fetch student data
$student = $conn->query("SELECT * FROM users WHERE id=$id AND role='student'")->fetchArray(SQLITE3_ASSOC);
if(!$student){
    echo "Student not found!";
    exit();
}

// Handle form submission
$message = "";
if(isset($_POST['update'])){
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    if($name && $email){
        // Update query
        if($password){
            $password_hash = password_hash($password, PASSWORD_DEFAULT);
            $conn->exec("UPDATE users SET name='".SQLite3::escapeString($name)."', email='".SQLite3::escapeString($email)."', password='$password_hash' WHERE id=$id");
        } else {
            $conn->exec("UPDATE users SET name='".SQLite3::escapeString($name)."', email='".SQLite3::escapeString($email)."' WHERE id=$id");
        }
        $message = "Student updated successfully!";
        // Refresh student data
        $student = $conn->query("SELECT * FROM users WHERE id=$id AND role='student'")->fetchArray(SQLITE3_ASSOC);
    } else {
        $message = "Name and Email cannot be empty!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Edit Student</title>
<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:Arial,sans-serif;
}

/* BODY */
body{
    background:linear-gradient(135deg,#eef2ff,#e0e7ff);
    min-height:100vh;
}

/* NAVBAR */
.navbar{
    display:flex;
    justify-content:space-between;
    align-items:center;
    padding:15px 40px;
    background:#111;
    color:#fff;
}

.nav-links a{
    color:#fff;
    margin-left:20px;
    text-decoration:none;
    font-size:16px;
}

.nav-links .btn{
    background:#fff;
    color:#000 !important;
    padding:6px 12px;
    border-radius:5px;
    font-size:16px;
}

/* CONTAINER */
.container{
    max-width:600px;
    margin:50px auto;
    padding:30px;
    background:#fff;
    border-radius:12px;
    box-shadow:0 6px 18px rgba(0,0,0,0.1);
}

/* HEADER */
.header{
    text-align:center;
    margin-bottom:30px;
}

.header h1{
    font-size:28px;
}

/* FORM */
form{
    display:flex;
    flex-direction:column;
}

form label{
    margin-bottom:5px;
    font-weight:bold;
}

form input{
    padding:10px;
    margin-bottom:20px;
    border-radius:6px;
    border:1px solid #ccc;
    font-size:16px;
}

form input[type="submit"]{
    background:#111;
    color:#fff;
    border:none;
    cursor:pointer;
    transition:0.3s;
}

form input[type="submit"]:hover{
    background:#333;
}

.message{
    text-align:center;
    margin-bottom:20px;
    font-weight:bold;
    color:green;
}
</style>
</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
    <div>🛡️ Admin Panel</div>
    <div class="nav-links">
        <a href="admin_dashboard.php">Dashboard</a>
        <a href="manage_students.php" class="active">Manage Students</a>
        <a href="../logout.php" class="btn">Logout</a>
    </div>
</div>

<div class="container">
<div class="header">
    <h1>Edit Student</h1>
</div>

<?php if($message){ ?>
    <div class="message"><?php echo $message; ?></div>
<?php } ?>

<form method="post">
    <label for="name">Name</label>
    <input type="text" name="name" id="name" value="<?php echo htmlspecialchars($student['name']); ?>" required>

    <label for="email">Email</label>
    <input type="email" name="email" id="email" value="<?php echo htmlspecialchars($student['email']); ?>" required>

    <label for="password">Password (leave blank to keep unchanged)</label>
    <input type="password" name="password" id="password" placeholder="Enter new password">

    <input type="submit" name="update" value="Update Student">
</form>
</div>

</body>
</html>