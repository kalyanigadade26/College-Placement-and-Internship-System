<?php
session_start();
include("../db.php");

// Protect page for admin only
if(!isset($_SESSION['user']) || $_SESSION['role'] != "admin"){
    header("Location: ../login.php");
    exit();
}

// Handle Delete Request
if(isset($_GET['delete'])){
    $id = (int)$_GET['delete'];
    $conn->exec("DELETE FROM users WHERE id=$id AND role='company'");
    header("Location: manage_companies.php");
    exit();
}

// Fetch all companies
$query = "SELECT * FROM users WHERE role='company' ORDER BY id DESC";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html>
<head>
<title>Manage Companies</title>
<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:Arial,sans-serif;
}

/* BODY */
body{
    background:linear-gradient(135deg,#eef2ff,#e0e7ff);
    min-height:100vh;
}

/* NAVBAR */
.navbar{
    display:flex;
    justify-content:space-between;
    align-items:center;
    padding:15px 40px;
    background:#111;
    color:#fff;
}

.nav-links a{
    color:#fff;
    margin-left:20px;
    text-decoration:none;
    font-size:16px;
}

.nav-links .btn{
    background:#fff;
    color:#000 !important;
    padding:6px 12px;
    border-radius:5px;
    font-size:16px;
}

/* CONTAINER */
.container{
    max-width:1200px;
    margin:50px auto;
    padding:20px;
    text-align:center;
}

/* HEADER */
.header{
    margin-bottom:40px;
}

.header h1{
    font-size:32px;
}

.header p{
    color:#555;
    font-size:17px;
    margin-top:10px;
}

/* TABLE */
table{
    width:100%;
    border-collapse:collapse;
    background:#fff;
    border-radius:10px;
    overflow:hidden;
    box-shadow:0 5px 15px rgba(0,0,0,0.1);
}

th, td{
    padding:12px 15px;
    text-align:left;
}

th{
    background:#111;
    color:#fff;
}

tr:nth-child(even){
    background:#f5f5f5;
}

.action-btn{
    background:#111;
    color:#fff;
    padding:6px 10px;
    text-decoration:none;
    border-radius:5px;
    font-size:14px;
    margin-right:5px;
}

.action-btn.delete{
    background:#c0392b;
}
</style>
</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
    <div>🛡️ Admin Panel</div>
    <div class="nav-links">
        <a href="../index.php">Home</a>
        <a href="../about.php">About</a>
        <a href="../contact.php">Contact</a>
        <a href="../feedback.php">Feedback</a> <!-- ✅ ADDED -->
        <a href="admin_dashboard.php">Dashboard</a>
        <a href="../logout.php" class="btn">Logout</a>
    </div>
</div>

<div class="container">

<div class="header">
    <h1>Manage Companies</h1>
    <p>View, edit, or delete company accounts</p>
</div>

<table>
<tr>
    <th>ID</th>
    <th>Company Name</th>
    <th>Email</th>
    <th>Actions</th>
</tr>

<?php while($row = $result->fetchArray(SQLITE3_ASSOC)) { ?>
<tr>
    <td><?php echo $row['id']; ?></td>
    <td><?php echo htmlspecialchars($row['name']); ?></td>
    <td><?php echo htmlspecialchars($row['email']); ?></td>
    <td>
        <a class="action-btn" href="edit_company.php?id=<?php echo $row['id']; ?>">Edit</a>
        <a class="action-btn delete" href="manage_companies.php?delete=<?php echo $row['id']; ?>" onclick="return confirm('Are you sure you want to delete this company?');">Delete</a>
    </td>
</tr>
<?php } ?>

</table>

</div>

</body>
</html>