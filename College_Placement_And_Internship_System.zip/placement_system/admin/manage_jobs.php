<?php
session_start();
include("../db.php");

// Protect page for admin only
if(!isset($_SESSION['user']) || $_SESSION['role'] != "admin"){
    header("Location: /placement_system/login.php");
    exit();
}

// Handle Delete Request
if(isset($_GET['delete'])){
    $id = (int)$_GET['delete'];
    $conn->exec("DELETE FROM jobs WHERE id=$id");
    header("Location: manage_jobs.php");
    exit();
}

// Fetch jobs
$query = "
SELECT jobs.id, jobs.title, jobs.location, users.name AS company_name
FROM jobs
JOIN users ON jobs.company_id = users.id
ORDER BY jobs.id DESC
";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html>
<head>
<title>Manage Job Postings</title>

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Segoe UI', sans-serif;
}

body{
    background:linear-gradient(135deg,#eef2ff,#e0e7ff);
}

/* NAVBAR */
.navbar{
    display:flex;
    justify-content:space-between;
    padding:18px 50px;
    background:#111;
    color:#fff;
}

.nav-links a{
    color:#fff;
    margin-left:25px;
    text-decoration:none;
}

.nav-links .btn{
    background:#fff;
    color:#000 !important;
    padding:6px 12px;
    border-radius:6px;
}

/* CONTAINER */
.container{
    max-width:1100px;
    margin:60px auto;
}

/* HEADER */
.header{
    text-align:center;
    margin-bottom:30px;
}

.header h1{
    font-size:30px;
}

.header p{
    color:#555;
}

/* TABLE BOX */
.table-box{
    background:#fff;
    padding:25px;
    border-radius:12px;
    box-shadow:0 10px 25px rgba(0,0,0,0.08);
}

/* TABLE */
table{
    width:100%;
    border-collapse:collapse;
}

th, td{
    padding:14px;
    border-bottom:1px solid #eee;
}

th{
    background:#111;
    color:#fff;
}

tr:hover{
    background:#f8fafc;
}

/* DELETE BUTTON */
.delete-btn{
    background:#dc2626;
    color:#fff;
    padding:6px 12px;
    border-radius:6px;
    text-decoration:none;
    font-size:14px;
}

.delete-btn:hover{
    background:#b91c1c;
}
</style>
</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
    <div>🛡️ Admin Panel</div>
    <div class="nav-links">
        <a href="/placement_system/index.php">Home</a>
        <a href="/placement_system/about.php">About</a>
        <a href="/placement_system/contact.php">Contact</a>
        <a href="/placement_system/feedback.php">Feedback</a> <!-- ✅ ADDED -->
        <a href="/placement_system/admin/admin_dashboard.php">Dashboard</a>
        <a href="/placement_system/logout.php" class="btn">Logout</a>
    </div>
</div>

<div class="container">

<div class="header">
    <h1>Manage Job Postings</h1>
    <p>View and delete job postings</p>
</div>

<div class="table-box">

<table>
<tr>
    <th>ID</th>
    <th>Job Title</th>
    <th>Company</th>
    <th>Location</th>
    <th>Action</th>
</tr>

<?php while($row = $result->fetchArray(SQLITE3_ASSOC)) { ?>
<tr>
    <td><?php echo $row['id']; ?></td>
    <td><?php echo htmlspecialchars($row['title']); ?></td>
    <td><?php echo htmlspecialchars($row['company_name']); ?></td>
    <td><?php echo htmlspecialchars($row['location']); ?></td>
    <td>
        <a class="delete-btn" 
           href="manage_jobs.php?delete=<?php echo $row['id']; ?>" 
           onclick="return confirm('Are you sure you want to delete this job?');">
           Delete
        </a>
    </td>
</tr>
<?php } ?>

</table>

</div>

</div>

</body>
</html>