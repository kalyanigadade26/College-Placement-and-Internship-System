<?php
session_start();
include("../db.php");

// Protect page
if(!isset($_SESSION['user']) || $_SESSION['role'] != "admin"){
    header("Location: /placement_system/login.php");
    exit();
}

// FETCH APPLICATIONS
$query = "
SELECT applications.id,
       applications.student_name,
       applications.student_email,
       applications.linkedin,
       applications.github,
       jobs.title AS job_title,
       jobs.location AS job_location
FROM applications
JOIN jobs ON applications.job_id = jobs.id
ORDER BY applications.id DESC
";

$result = $conn->query($query);
?>

<!DOCTYPE html>
<html>
<head>
<title>View Applications</title>

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Segoe UI', sans-serif;
}

body{
    background:linear-gradient(135deg,#eef2ff,#e0e7ff);
}

/* NAVBAR */
.navbar{
    display:flex;
    justify-content:space-between;
    padding:18px 50px;
    background:#111;
    color:#fff;
}

.nav-links a{
    color:#fff;
    margin-left:25px;
    text-decoration:none;
}

.nav-links .btn{
    background:#fff;
    color:#000 !important;
    padding:6px 12px;
    border-radius:6px;
}

/* CONTAINER */
.container{
    max-width:1200px;
    margin:60px auto;
}

/* HEADER */
.header{
    text-align:center;
    margin-bottom:30px;
}

.header h1{
    font-size:30px;
}

.header p{
    color:#555;
}

/* TABLE BOX */
.table-box{
    background:#fff;
    padding:25px;
    border-radius:12px;
    box-shadow:0 10px 25px rgba(0,0,0,0.08);
}

/* TABLE */
table{
    width:100%;
    border-collapse:collapse;
}

th, td{
    padding:14px;
    border-bottom:1px solid #eee;
}

th{
    background:#111;
    color:#fff;
}

tr:hover{
    background:#f8fafc;
}

/* LINKS */
a.link{
    color:#2563eb;
    text-decoration:none;
    font-weight:500;
}

a.link:hover{
    text-decoration:underline;
}
</style>

</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
    <div>🛡️ Admin Panel</div>

    <div class="nav-links">
        <a href="/placement_system/index.php">Home</a>
        <a href="/placement_system/about.php">About</a>
        <a href="/placement_system/contact.php">Contact</a>
        <a href="/placement_system/feedback.php">Feedback</a> <!-- ✅ ADDED -->
        <a href="/placement_system/admin/admin_dashboard.php">Dashboard</a>
        <a href="/placement_system/logout.php" class="btn">Logout</a>
    </div>
</div>

<!-- CONTENT -->
<div class="container">

<div class="header">
    <h1>Student Applications</h1>
    <p>View all submitted applications</p>
</div>

<div class="table-box">

<table>
<tr>
    <th>ID</th>
    <th>Name</th>
    <th>Email</th>
    <th>Job</th>
    <th>Location</th>
    <th>LinkedIn</th>
    <th>GitHub</th>
</tr>

<?php while($row = $result->fetchArray(SQLITE3_ASSOC)) { ?>
<tr>
    <td><?php echo $row['id']; ?></td>
    <td><?php echo htmlspecialchars($row['student_name']); ?></td>
    <td><?php echo htmlspecialchars($row['student_email']); ?></td>
    <td><?php echo htmlspecialchars($row['job_title']); ?></td>
    <td><?php echo htmlspecialchars($row['job_location']); ?></td>

    <td>
        <a class="link" href="<?php echo htmlspecialchars($row['linkedin']); ?>" target="_blank">
            View
        </a>
    </td>

    <td>
        <?php if(!empty($row['github'])) { ?>
            <a class="link" href="<?php echo htmlspecialchars($row['github']); ?>" target="_blank">
                View
            </a>
        <?php } else { echo "-"; } ?>
    </td>
</tr>
<?php } ?>

</table>

</div>

</div>

</body>
</html>