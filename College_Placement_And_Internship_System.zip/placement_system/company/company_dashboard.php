<?php
session_start();

// Protect page
if(!isset($_SESSION['user']) || $_SESSION['role'] != "company"){
    header("Location: /placement_system/login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Company Dashboard</title>

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:Arial, sans-serif;
}

/* BODY */
body{
    background:linear-gradient(135deg,#eef2ff,#e0e7ff);
    min-height:100vh;
}

/* NAVBAR */
.navbar{
    display:flex;
    justify-content:space-between;
    padding:15px 40px;
    background:#111;
    color:#fff;
}

.nav-links a{
    color:#fff;
    margin-left:20px;
    text-decoration:none;
}

.nav-links .btn{
    background:#fff;
    color:#000 !important;
    padding:6px 12px;
    border-radius:5px;
}

/* CONTAINER */
.container{
    padding:50px;
}

/* HEADER */
.header{
    text-align:center;
    margin-bottom:40px;
}

.header h1{
    font-size:28px;
}

.header p{
    color:#555;
}

/* GRID */
.grid{
    display:grid;
    grid-template-columns:repeat(auto-fit, minmax(250px,1fr));
    gap:25px;
}

/* CARD */
.card{
    background:#fff;
    padding:25px;
    border-radius:12px;
    box-shadow:0 6px 18px rgba(0,0,0,0.1);
    text-align:center;
    transition:0.3s;
}

.card:hover{
    transform:translateY(-5px);
}

/* TITLE */
.card h3{
    margin-bottom:10px;
}

/* TEXT */
.card p{
    color:#666;
    margin-bottom:20px;
}

/* BUTTON */
.card a{
    display:inline-block;
    padding:10px 15px;
    background:#111;
    color:#fff;
    text-decoration:none;
    border-radius:6px;
    font-size:14px;
}
</style>

</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
    <div>🏢 Company Panel</div>

    <div class="nav-links">
        <a href="/placement_system/index.php">Home</a>
        <a href="/placement_system/about.php">About</a>
        <a href="/placement_system/contact.php">Contact</a>
        <a href="/placement_system/feedback.php">Feedback</a> <!-- ✅ ADDED -->
        <a href="/placement_system/company/company_dashboard.php">Dashboard</a>
        <a href="/placement_system/logout.php" class="btn">Logout</a>
    </div>
</div>

<!-- DASHBOARD -->
<div class="container">

<div class="header">
    <h1>Welcome, <?php echo $_SESSION['user']; ?> 👋</h1>
    <p>Manage your job postings and find the best candidates</p>
</div>

<div class="grid">

    <!-- POST JOB -->
    <div class="card">
        <h3>Post Job</h3>
        <p>Create new job or internship opportunities</p>
        <a href="/placement_system/company/post_job.php">Post Job</a>
    </div>

    <!-- MANAGE JOBS -->
    <div class="card">
        <h3>Manage Jobs</h3>
        <p>Edit or delete your job postings</p>
        <a href="/placement_system/company/manage_jobs.php">Manage Jobs</a>
    </div>

    <!-- VIEW APPLICATIONS -->
    <div class="card">
        <h3>Applications</h3>
        <p>View students who applied to your jobs</p>
        <a href="/placement_system/company/view_applications.php">View Applications</a>
    </div>

</div>

</div>

</body>
</html>