<?php
session_start();
include("../db.php");

// Protect page
if(!isset($_SESSION['user']) || $_SESSION['role'] != "company"){
    header("Location: ../login.php");
    exit();
}

$company_id = $_SESSION['user_id'];

// DELETE JOB
if(isset($_GET['delete'])){
    $job_id = $_GET['delete'];

    $stmt = $conn->prepare("DELETE FROM jobs WHERE id=? AND company_id=?");
    $stmt->bindValue(1, $job_id);
    $stmt->bindValue(2, $company_id);
    $stmt->execute();

    header("Location: manage_jobs.php");
    exit();
}

// FETCH JOBS
$stmt = $conn->prepare("SELECT * FROM jobs WHERE company_id=? ORDER BY id DESC");
$stmt->bindValue(1, $company_id);
$result = $stmt->execute();
?>

<!DOCTYPE html>
<html>
<head>
<title>Manage Jobs</title>

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:Arial;
}

/* BODY */
body{
    background:linear-gradient(135deg,#eef2ff,#e0e7ff);
}

/* NAVBAR */
.navbar{
    display:flex;
    justify-content:space-between;
    padding:15px 40px;
    background:#111;
    color:#fff;
}

.nav-links a{
    color:#fff;
    margin-left:20px;
    text-decoration:none;
}

.nav-links .btn{
    background:#fff;
    color:#000 !important;
    padding:6px 12px;
    border-radius:5px;
}

/* CONTAINER */
.container{
    padding:40px;
}

/* TITLE */
h2{
    text-align:center;
    margin-bottom:30px;
}

/* TABLE */
table{
    width:100%;
    border-collapse:collapse;
    background:#fff;
    border-radius:10px;
    overflow:hidden;
    box-shadow:0 5px 15px rgba(0,0,0,0.1);
}

th, td{
    padding:15px;
    text-align:left;
}

th{
    background:#111;
    color:#fff;
}

tr:nth-child(even){
    background:#f5f5f5;
}

/* BUTTON */
.delete-btn{
    background:red;
    color:#fff;
    padding:6px 10px;
    text-decoration:none;
    border-radius:5px;
}
</style>

</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
    <div>🏢 Company Panel</div>

    <div class="nav-links">
        <a href="../index.php">Home</a>
        <a href="../about.php">About</a>
        <a href="../contact.php">Contact</a>
        <a href="../feedback.php">Feedback</a> <!-- ✅ ADDED -->
        <a href="company_dashboard.php">Dashboard</a>
        <a href="../logout.php" class="btn">Logout</a>
    </div>
</div>

<div class="container">

<h2>Manage Jobs</h2>

<table>
<tr>
    <th>ID</th>
    <th>Title</th>
    <th>Location</th>
    <th>Description</th>
    <th>Action</th>
</tr>

<?php while($job = $result->fetchArray(SQLITE3_ASSOC)) { ?>
<tr>
    <td><?php echo $job['id']; ?></td>
    <td><?php echo htmlspecialchars($job['title']); ?></td>
    <td><?php echo htmlspecialchars($job['location']); ?></td>
    <td><?php echo htmlspecialchars($job['description']); ?></td>
    <td>
        <a href="manage_jobs.php?delete=<?php echo $job['id']; ?>" 
           class="delete-btn"
           onclick="return confirm('Delete this job?')">
           Delete
        </a>
    </td>
</tr>
<?php } ?>

</table>

</div>

</body>
</html>