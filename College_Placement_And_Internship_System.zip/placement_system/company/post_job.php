<?php
session_start();
include("../db.php");

// Protect page
if(!isset($_SESSION['user']) || $_SESSION['role'] != "company"){
    header("Location: ../login.php");
    exit();
}

// Check user_id
if(!isset($_SESSION['user_id'])){
    die("Session expired. Please login again.");
}

$company_id = $_SESSION['user_id'];

if($_SERVER["REQUEST_METHOD"] == "POST"){

    $title = $_POST['title'];
    $company = $_POST['company'];
    $location = $_POST['location'];
    $description = $_POST['description'];

    $stmt = $conn->prepare("INSERT INTO jobs (title, company, location, description, company_id) VALUES (?, ?, ?, ?, ?)");
    $stmt->bindValue(1, $title);
    $stmt->bindValue(2, $company);
    $stmt->bindValue(3, $location);
    $stmt->bindValue(4, $description);
    $stmt->bindValue(5, $company_id);

    if($stmt->execute()){
        $success = "Job posted successfully!";
    } else {
        $error = "Failed to post job!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Post Job</title>

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:Arial;
}

/* BODY */
body{
    background:linear-gradient(135deg,#eef2ff,#e0e7ff);
}

/* NAVBAR */
.navbar{
    display:flex;
    justify-content:space-between;
    padding:15px 40px;
    background:#111;
    color:#fff;
}

.nav-links a{
    color:#fff;
    margin-left:20px;
    text-decoration:none;
}

.nav-links .btn{
    background:#fff;
    color:#000 !important;
    padding:6px 12px;
    border-radius:5px;
}

/* CENTER */
.container{
    display:flex;
    justify-content:center;
    align-items:center;
    height:calc(100vh - 70px);
}

/* CARD */
.card{
    background:#fff;
    padding:30px;
    width:450px;
    border-radius:12px;
    box-shadow:0 6px 18px rgba(0,0,0,0.1);
}

.card h2{
    text-align:center;
    margin-bottom:20px;
}

/* INPUT */
input, textarea{
    width:100%;
    padding:10px;
    margin:10px 0;
}

/* BUTTON */
button{
    width:100%;
    padding:10px;
    background:#111;
    color:#fff;
    border:none;
    margin-top:10px;
    cursor:pointer;
}

/* MESSAGE */
.success{color:green;text-align:center;}
.error{color:red;text-align:center;}
</style>

</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
    <div>🏢 Company Panel</div>

    <div class="nav-links">
        <a href="../index.php">Home</a>
        <a href="../about.php">About</a>
        <a href="../contact.php">Contact</a>
        <a href="../feedback.php">Feedback</a> <!-- ✅ ADDED -->
        <a href="company_dashboard.php">Dashboard</a>
        <a href="../logout.php" class="btn">Logout</a>
    </div>
</div>

<!-- FORM -->
<div class="container">
<div class="card">

<h2>Post New Job</h2>

<?php if(isset($success)) echo "<p class='success'>$success</p>"; ?>
<?php if(isset($error)) echo "<p class='error'>$error</p>"; ?>

<form method="post">

<input type="text" name="title" placeholder="Job Title" required>

<input type="text" name="company" placeholder="Company Name" required>

<input type="text" name="location" placeholder="Location" required>

<textarea name="description" placeholder="Job Description" rows="4" required></textarea>

<button>Post Job</button>

</form>

</div>
</div>

</body>
</html>