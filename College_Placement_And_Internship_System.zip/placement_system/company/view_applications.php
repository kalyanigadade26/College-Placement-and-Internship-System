<?php
session_start();
include("../db.php");

// Protect page
if(!isset($_SESSION['user']) || $_SESSION['role'] != "company"){
    header("Location: /placement_system/login.php");
    exit();
}

$company_id = $_SESSION['user_id'];

// SAFE QUERY
$stmt = $conn->prepare("
SELECT applications.id,
       applications.student_name,
       applications.student_email,
       applications.linkedin,
       applications.github,
       jobs.title
FROM applications
JOIN jobs ON applications.job_id = jobs.id
WHERE jobs.company_id = ?
ORDER BY applications.id DESC
");

$stmt->bindValue(1, $company_id, SQLITE3_INTEGER);
$result = $stmt->execute();
?>

<!DOCTYPE html>
<html>
<head>
<title>View Applications</title>

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Segoe UI', sans-serif;
}

body{
    background:linear-gradient(135deg,#eef2ff,#e0e7ff);
}

/* NAVBAR */
.navbar{
    display:flex;
    justify-content:space-between;
    padding:18px 50px;
    background:#111;
    color:#fff;
}

.nav-links a{
    color:#fff;
    margin-left:25px;
    text-decoration:none;
}

.nav-links .btn{
    background:#fff;
    color:#000 !important;
    padding:6px 12px;
    border-radius:6px;
}

/* CONTAINER */
.container{
    max-width:1100px;
    margin:60px auto;
}

/* TITLE */
h2{
    text-align:center;
    margin-bottom:30px;
}

/* TABLE BOX */
.table-box{
    background:#fff;
    padding:25px;
    border-radius:12px;
    box-shadow:0 10px 25px rgba(0,0,0,0.08);
}

/* TABLE */
table{
    width:100%;
    border-collapse:collapse;
}

th, td{
    padding:14px;
    border-bottom:1px solid #eee;
}

th{
    background:#111;
    color:#fff;
}

tr:hover{
    background:#f8fafc;
}

/* LINKS */
a.link{
    color:#2563eb;
    text-decoration:none;
    font-weight:500;
}

a.link:hover{
    text-decoration:underline;
}

/* EMPTY */
.empty{
    text-align:center;
    padding:20px;
    color:#555;
}
</style>

</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
    <div>🏢 Company Panel</div>

    <div class="nav-links">
        <a href="/placement_system/index.php">Home</a>
        <a href="/placement_system/about.php">About</a>
        <a href="/placement_system/contact.php">Contact</a>
        <a href="/placement_system/feedback.php">Feedback</a> <!-- ✅ ADDED -->
        <a href="/placement_system/company/company_dashboard.php">Dashboard</a>
        <a href="/placement_system/logout.php" class="btn">Logout</a>
    </div>
</div>

<div class="container">

<h2>Student Applications</h2>

<div class="table-box">

<?php 
$hasData = false;
while($row = $result->fetchArray(SQLITE3_ASSOC)) {
    if(!$hasData){
        $hasData = true;
?>

<table>
<tr>
    <th>ID</th>
    <th>Name</th>
    <th>Email</th>
    <th>Job</th>
    <th>LinkedIn</th>
    <th>GitHub</th>
</tr>

<?php } ?>

<tr>
    <td><?php echo $row['id']; ?></td>
    <td><?php echo htmlspecialchars($row['student_name']); ?></td>
    <td><?php echo htmlspecialchars($row['student_email']); ?></td>
    <td><?php echo htmlspecialchars($row['title']); ?></td>

    <td>
        <a class="link" href="<?php echo $row['linkedin']; ?>" target="_blank">View</a>
    </td>

    <td>
        <?php if(!empty($row['github'])) { ?>
            <a class="link" href="<?php echo $row['github']; ?>" target="_blank">View</a>
        <?php } else { echo "-"; } ?>
    </td>
</tr>

<?php } ?>

<?php if($hasData) { ?>
</table>
<?php } else { ?>
<p class="empty">No applications received yet.</p>
<?php } ?>

</div>

</div>

</body>
</html>