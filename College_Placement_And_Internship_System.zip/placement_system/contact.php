<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Contact Us</title>
<link rel="stylesheet" href="css/style.css">
</head>

<body>

<!-- NAVBAR -->
<header class="navbar">
    <div class="logo">🎓 College Placement and Internship System</div>

    <nav class="nav-links">
        <a href="/placement_system/index.php">Home</a>
        <a href="/placement_system/about.php">About Us</a>
        <a href="/placement_system/contact.php">Contact Us</a>
        <a href="/placement_system/feedback.php">Feedback</a> <!-- ✅ ADDED -->

        <?php if(isset($_SESSION['user'])) { ?>

            <?php if($_SESSION['role'] == "student") { ?>
                <a href="/placement_system/student/student_dashboard.php" class="btn">Dashboard</a>
            <?php } elseif($_SESSION['role'] == "admin") { ?>
                <a href="/placement_system/admin/admin_dashboard.php" class="btn">Dashboard</a>
            <?php } elseif($_SESSION['role'] == "company") { ?>
                <a href="/placement_system/company/company_dashboard.php" class="btn">Dashboard</a>
            <?php } ?>

            <a href="/placement_system/logout.php" class="btn">Logout</a>

        <?php } else { ?>
            <a href="/placement_system/login.php" class="btn">Login</a>
            <a href="/placement_system/register.php" class="btn">Register</a>
        <?php } ?>
    </nav>
</header>

<!-- HERO -->
<section class="contact-hero">
    <div class="overlay"></div>

    <div class="hero-content">
        <h1>Contact Us</h1>
        <p>We would love to hear from you</p>
    </div>
</section>

<!-- CONTACT -->
<section class="contact-section">
    <div class="contact-container">

        <!-- INFO -->
        <div class="contact-card">
            <h2>📍 Get In Touch</h2>
            <p><strong>Address:</strong> Your College</p>
            <p><strong>Email:</strong> placement@college.com</p>
            <p><strong>Phone:</strong> +91 9876543210</p>
        </div>

        <!-- FORM -->
        <div class="contact-card">
            <h2>✉ Send Message</h2>

            <form method="post">
                <input type="text" name="name" placeholder="Your Name" required>
                <input type="email" name="email" placeholder="Your Email" required>
                <textarea name="message" rows="5" placeholder="Message" required></textarea>
                <button type="submit">Send Message</button>
            </form>

            <?php
            if($_SERVER["REQUEST_METHOD"] == "POST") {
                echo "<p style='color:green; margin-top:10px;'>Message sent successfully!</p>";
            }
            ?>
        </div>

    </div>
</section>

</body>
</html>