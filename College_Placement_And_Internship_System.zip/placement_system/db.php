<?php
$conn = new SQLite3(__DIR__ . '/database/database.sqlite');
?>