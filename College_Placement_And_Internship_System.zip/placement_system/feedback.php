<?php
session_start();
include("db.php");

$success = "";
$error = "";

if($_SERVER["REQUEST_METHOD"] == "POST"){
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $message = trim($_POST['message']);

    if(empty($name) || empty($email) || empty($message)){
        $error = "All fields are required!";
    } else {
        $stmt = $conn->prepare("INSERT INTO feedback (name, email, message) VALUES (?, ?, ?)");
        $stmt->bindValue(1, $name, SQLITE3_TEXT);
        $stmt->bindValue(2, $email, SQLITE3_TEXT);
        $stmt->bindValue(3, $message, SQLITE3_TEXT);

        if($stmt->execute()){
            $success = "Thank you! Your feedback has been submitted.";
        } else {
            $error = "Something went wrong. Try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Feedback</title>
<link rel="stylesheet" href="css/style.css">
</head>

<body>

<!-- NAVBAR -->
<header class="navbar">
    <div class="logo">🎓 College Placement and Internship System</div>

    <nav class="nav-links">
        <a href="index.php">Home</a>
        <a href="about.php">About</a>
        <a href="contact.php">Contact</a>
        <a href="feedback.php" class="active">Feedback</a>

        <?php if(isset($_SESSION['user'])) { ?>

            <?php
            if($_SESSION['role']=="admin"){
                $dashboard="admin/admin_dashboard.php";
            } elseif($_SESSION['role']=="company"){
                $dashboard="company/company_dashboard.php";
            } else {
                $dashboard="student/student_dashboard.php";
            }
            ?>

            <a href="<?php echo $dashboard; ?>" class="btn">Dashboard</a>
            <a href="logout.php" class="btn">Logout</a>

        <?php } else { ?>
            <a href="login.php" class="btn">Login</a>
            <a href="register.php" class="btn">Register</a>
        <?php } ?>
    </nav>
</header>

<!-- HERO -->
<section class="contact-hero">
    <div class="overlay"></div>

    <div class="hero-content">
        <h1>Feedback</h1>
        <p>Your opinion helps us improve</p>
    </div>
</section>

<!-- FEEDBACK SECTION -->
<section class="contact-section">
    <div class="contact-container">

        <!-- INFO -->
        <div class="contact-card">
            <h2>💡 Why Feedback Matters</h2>
            <p>We value your experience and suggestions.</p>
            <p>Your feedback helps us improve the platform.</p>
            <p>Share your thoughts and help us grow better.</p>
        </div>

        <!-- FORM -->
        <div class="contact-card">
            <h2>✍ Submit Feedback</h2>

            <?php if($success) echo "<p style='color:green;'>$success</p>"; ?>
            <?php if($error) echo "<p style='color:red;'>$error</p>"; ?>

            <form method="POST">
                <input type="text" name="name" placeholder="Your Name" required>
                <input type="email" name="email" placeholder="Your Email" required>
                <textarea name="message" rows="5" placeholder="Your Feedback..." required></textarea>
                <button type="submit">Submit Feedback</button>
            </form>
        </div>

    </div>
</section>

</body>
</html>