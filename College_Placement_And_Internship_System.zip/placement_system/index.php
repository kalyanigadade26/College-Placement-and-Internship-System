<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Placement Portal</title>
<link rel="stylesheet" href="css/style.css">
</head>

<body>

<header class="navbar">
    <div class="logo">🎓 College Placement and Internship System</div>

    <nav class="nav-links">
        <a href="index.php" class="active">Home</a>
        <a href="about.php">About Us</a>
        <a href="contact.php">Contact Us</a>
        <a href="feedback.php">Feedback</a> <!-- ✅ ADDED -->

        <?php if(isset($_SESSION['user'])) { ?>

            <?php
            // ROLE-BASED DASHBOARD LINK
            if($_SESSION['role'] == "admin") {
                $dashboard = "admin/admin_dashboard.php";
            } elseif($_SESSION['role'] == "company") {
                $dashboard = "company/company_dashboard.php";
            } else {
                $dashboard = "student/student_dashboard.php";
            }
            ?>

            <!-- SHOW USER NAME -->
            <span style="margin-right:10px;">👋 <?php echo $_SESSION['user']; ?></span>

            <a href="<?php echo $dashboard; ?>" class="btn">Dashboard</a>
            <a href="logout.php" class="btn">Logout</a>

        <?php } else { ?>
            <a href="login.php" class="btn">Login</a>
            <a href="register.php" class="btn">Register</a>
        <?php } ?>
    </nav>
</header>

<section class="hero">
    <div class="overlay"></div>

    <div class="hero-content">
        <h1>Shape Your Future With The Right Opportunity</h1>
        <p>Connecting Students with Top Companies</p>

        <div class="hero-buttons">
            <a href="register.php" class="primary-btn">Get Started</a>
            <a href="about.php" class="secondary-btn">Learn More</a>
        </div>
    </div>
</section>

</body>
</html>