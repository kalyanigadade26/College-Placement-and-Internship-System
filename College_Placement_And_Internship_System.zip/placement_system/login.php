<?php
session_start();
include("db.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    // Fetch user by email
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = :email");
    $stmt->bindValue(':email', $email, SQLITE3_TEXT);

    $result = $stmt->execute();
    $user = $result->fetchArray(SQLITE3_ASSOC);

    // ✅ Correct password check
    if ($user && password_verify($password, $user['password'])) {

        $_SESSION['user'] = $user['name'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['user_id'] = $user['id'];

        // Redirect by role
        if ($user['role'] == "admin") {
            header("Location: admin/admin_dashboard.php");
        } elseif ($user['role'] == "company") {
            header("Location: company/company_dashboard.php");
        } else {
            header("Location: student/student_dashboard.php");
        }
        exit();

    } else {
        $error = "Invalid email or password!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Login</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family:Arial;
}

/* NAVBAR */
.navbar{
    display:flex;
    justify-content:space-between;
    align-items:center;
    padding:15px 30px;
    background:#111;
    color:#fff;
}

.nav-links a{
    color:#fff;
    margin-left:15px;
    text-decoration:none;
}

.nav-links .btn{
    background:#fff;
    color:#000 !important;
    padding:6px 12px;
    border-radius:5px;
}

/* LOGIN SECTION */
.login-section{
    height:calc(100vh - 70px);
    display:flex;
    justify-content:center;
    align-items:center;
    background:linear-gradient(135deg,#f1f5f9,#e2e8f0);
}

/* CARD */
.card{
    background:#fff;
    padding:30px;
    border-radius:10px;
    width:350px;
    text-align:center;
    box-shadow:0 5px 15px rgba(0,0,0,0.1);
}

/* INPUT */
.input-box{
    position:relative;
    margin:10px 0;
}

.input-box i{
    position:absolute;
    top:50%;
    left:10px;
    transform:translateY(-50%);
    color:#555;
}

.input-box input{
    width:100%;
    padding:10px 10px 10px 35px;
}

/* BUTTON */
.card button{
    width:100%;
    padding:10px;
    background:#000;
    color:#fff;
    border:none;
    cursor:pointer;
    margin-top:10px;
}

.card p{
    margin-top:20px;
}

.error{
    color:red;
    margin-bottom:10px;
}
</style>
</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
    <div>🎓 College Placement and Internship System</div>

    <div class="nav-links">
        <a href="index.php">Home</a>
        <a href="about.php">About Us</a>
        <a href="contact.php">Contact Us</a>
        <a href="feedback.php">Feedback</a>

        <?php if (isset($_SESSION['user'])) { ?>

            <?php
            if ($_SESSION['role'] == "admin") {
                $dash = "admin/admin_dashboard.php";
            } elseif ($_SESSION['role'] == "company") {
                $dash = "company/company_dashboard.php";
            } else {
                $dash = "student/student_dashboard.php";
            }
            ?>

            <a href="<?php echo $dash; ?>" class="btn">Dashboard</a>
            <a href="logout.php" class="btn">Logout</a>

        <?php } else { ?>
            <a href="register.php" class="btn">Register</a>
        <?php } ?>

    </div>
</div>

<!-- LOGIN FORM -->
<section class="login-section">
    <div class="card">

        <h2>Login</h2>

        <?php if (isset($error)) { ?>
            <p class="error"><?php echo $error; ?></p>
        <?php } ?>

        <form method="post">

            <div class="input-box">
                <i class="fa fa-envelope"></i>
                <input type="email" name="email" placeholder="Email" required>
            </div>

            <div class="input-box">
                <i class="fa fa-lock"></i>
                <input type="password" name="password" placeholder="Password" required>
            </div>

            <button type="submit">Login</button>

        </form>

        <p>Don't have account? <a href="register.php">Register</a></p>

    </div>
</section>

</body>
</html>