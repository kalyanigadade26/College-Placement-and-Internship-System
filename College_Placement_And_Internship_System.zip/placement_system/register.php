<?php
session_start();
include("db.php");

if($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $role = $_POST['role'];

    // Hash password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    $check = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $check->bindValue(1, $email);
    $res = $check->execute();

    if($res->fetchArray()) {
        echo "<script>alert('Email already exists!');</script>";
    } else {

        $stmt = $conn->prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)");
        $stmt->bindValue(1, $name);
        $stmt->bindValue(2, $email);
        $stmt->bindValue(3, $hashed_password);
        $stmt->bindValue(4, $role);

        if($stmt->execute()) {
            echo "<script>alert('Registration successful! Please login.'); window.location.href='login.php';</script>";
            exit();
        } else {
            echo "<script>alert('Registration failed! Try again.');</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Register</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:Arial;}

/* NAVBAR */
.navbar{
    display:flex;
    justify-content:space-between;
    align-items:center;
    padding:15px 40px;
    background:#111;
    color:#fff;
}

.nav-links a{
    color:#fff;
    margin-left:20px;
    text-decoration:none;
}

.nav-links .btn{
    background:#fff;
    color:#000 !important;
    padding:6px 12px;
    border-radius:5px;
}

/* CENTER */
.register-section{
    height:calc(100vh - 70px);
    display:flex;
    justify-content:center;
    align-items:center;
    background:linear-gradient(135deg,#eef2ff,#e0e7ff);
}

/* CARD */
.card{
    background:#fff;
    padding:30px;
    border-radius:12px;
    width:350px;
    text-align:center;
    box-shadow:0 5px 15px rgba(0,0,0,0.1);
}

/* INPUT */
.input-box{
    position:relative;
    margin:12px 0;
}

.input-box i{
    position:absolute;
    top:50%;
    left:10px;
    transform:translateY(-50%);
    color:#555;
}

.input-box input,
.input-box select{
    width:100%;
    padding:10px 10px 10px 35px;
}

/* BUTTON */
.card button{
    width:100%;
    padding:10px;
    background:#111;
    color:#fff;
    border:none;
    margin-top:10px;
    border-radius:6px;
    cursor:pointer;
}

.card button:hover{
    background:#333;
}

.card p{
    margin-top:20px;
}
</style>
</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
    <div>🎓 College Placement and Internship System</div>

    <div class="nav-links">
        <a href="index.php">Home</a>
        <a href="about.php">About Us</a>
        <a href="contact.php">Contact Us</a>
        <a href="feedback.php">Feedback</a>

        <?php if(isset($_SESSION['user'])) { ?>

            <?php
            if($_SESSION['role']=="admin"){
                $dash="admin/admin_dashboard.php";
            } elseif($_SESSION['role']=="company"){
                $dash="company/company_dashboard.php";
            } else {
                $dash="student/student_dashboard.php";
            }
            ?>

            <a href="<?php echo $dash; ?>" class="btn">Dashboard</a>
            <a href="logout.php" class="btn">Logout</a>

        <?php } else { ?>
            <a href="login.php" class="btn">Login</a>
        <?php } ?>
    </div>
</div>

<!-- REGISTER FORM -->
<section class="register-section">
<div class="card">

<h2>Register</h2>

<form method="post">

<div class="input-box">
<i class="fa fa-user"></i>
<input type="text" name="name" placeholder="Name" required>
</div>

<div class="input-box">
<i class="fa fa-envelope"></i>
<input type="email" name="email" placeholder="Email" required>
</div>

<div class="input-box">
<i class="fa fa-lock"></i>
<input type="password" name="password" placeholder="Password" required>
</div>

<div class="input-box">
<i class="fa fa-users"></i>
<select name="role" required>
<option value="">Select Role</option>
<option value="student">Student</option>
<option value="company">Company</option>
<option value="admin">Admin</option>
</select>
</div>

<button>Register</button>

</form>

<p>Already have an account? <a href="login.php">Login</a></p>

</div>
</section>

</body>
</html>