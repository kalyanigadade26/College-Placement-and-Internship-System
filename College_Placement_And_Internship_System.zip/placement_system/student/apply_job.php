<?php
session_start();
include("../db.php");

// Protect page
if(!isset($_SESSION['user']) || $_SESSION['role'] != "student") {
    header("Location: /placement_system/login.php");
    exit();
}

// Get job ID
if(!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: view_jobs.php");
    exit();
}

$job_id = intval($_GET['id']);

// Fetch job
$stmt = $conn->prepare("SELECT * FROM jobs WHERE id = ?");
$stmt->bindValue(1, $job_id, SQLITE3_INTEGER);
$job = $stmt->execute()->fetchArray();

if(!$job) {
    echo "Job not found!";
    exit();
}

$success_msg = "";
$error_msg = "";

// Handle form
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $student_name = $_POST['name'];
    $student_email = $_POST['email'];
    $linkedin = $_POST['linkedin'];
    $github = $_POST['github'];

    if(empty($student_name) || empty($student_email) || empty($linkedin)) {
        $error_msg = "Name, Email and LinkedIn are required!";
    } else {

        $insert = $conn->prepare("INSERT INTO applications (job_id, student_email, student_name, linkedin, github) VALUES (?, ?, ?, ?, ?)");
        $insert->bindValue(1, $job_id, SQLITE3_INTEGER);
        $insert->bindValue(2, $student_email, SQLITE3_TEXT);
        $insert->bindValue(3, $student_name, SQLITE3_TEXT);
        $insert->bindValue(4, $linkedin, SQLITE3_TEXT);
        $insert->bindValue(5, $github, SQLITE3_TEXT);

        if($insert->execute()) {
            $success_msg = "Application submitted successfully!";
        } else {
            $error_msg = "Failed to submit application!";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Apply Job</title>

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Segoe UI', Tahoma, sans-serif;
}

body{
    background:linear-gradient(135deg,#eef2ff,#e0e7ff);
    min-height:100vh;
}

/* NAVBAR */
.navbar{
    display:flex;
    justify-content:space-between;
    align-items:center;
    padding:18px 50px;
    background:#111;
    color:#fff;
}

.nav-links a{
    color:#fff;
    margin-left:25px;
    text-decoration:none;
    font-size:15px;
}

.nav-links .btn{
    background:#fff;
    color:#000 !important;
    padding:7px 14px;
    border-radius:6px;
    font-weight:500;
}

/* CONTAINER */
.container{
    max-width:720px;
    margin:60px auto;
    background:#fff;
    padding:40px;
    border-radius:14px;
    box-shadow:0 10px 25px rgba(0,0,0,0.08);
}

/* TITLE */
h1{
    text-align:center;
    margin-bottom:30px;
    font-size:28px;
    color:#222;
}

/* JOB DETAILS */
.job-details p{
    margin-bottom:10px;
    color:#555;
}

/* FORM */
form{
    margin-top:25px;
}

/* INPUT */
form input{
    width:100%;
    padding:12px;
    margin-bottom:18px;
    border:1px solid #ddd;
    border-radius:8px;
    font-size:15px;
    transition:0.2s;
}

form input:focus{
    border-color:#6366f1;
    outline:none;
    box-shadow:0 0 0 2px rgba(99,102,241,0.15);
}

/* BUTTON */
form button{
    width:100%;
    padding:12px;
    background:#111;
    color:#fff;
    border:none;
    border-radius:8px;
    font-size:16px;
    font-weight:500;
    cursor:pointer;
    transition:0.3s;
}

form button:hover{
    background:#333;
}

/* MESSAGES */
.success{
    color:#16a34a;
    text-align:center;
    margin-bottom:15px;
    font-weight:500;
}

.error{
    color:#dc2626;
    text-align:center;
    margin-bottom:15px;
    font-weight:500;
}
</style>

</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
    <div>🎓 Student Panel</div>
    <div class="nav-links">
        <a href="/placement_system/index.php">Home</a>
        <a href="/placement_system/about.php">About</a>
        <a href="/placement_system/contact.php">Contact</a>
        <a href="/placement_system/feedback.php">Feedback</a> <!-- ✅ ADDED -->
        <a href="/placement_system/student/student_dashboard.php">Dashboard</a>
        <a href="/placement_system/logout.php" class="btn">Logout</a>
    </div>
</div>

<!-- MAIN -->
<div class="container">

    <h1>Apply for Job</h1>

    <div class="job-details">
        <p><b>Job Title:</b> <?php echo htmlspecialchars($job['title']); ?></p>
        <p><b>Company:</b> <?php echo htmlspecialchars($job['company']); ?></p>
        <p><b>Location:</b> <?php echo htmlspecialchars($job['location']); ?></p>
    </div>

    <?php if($success_msg) echo "<div class='success'>$success_msg</div>"; ?>
    <?php if($error_msg) echo "<div class='error'>$error_msg</div>"; ?>

    <form method="POST">
        <input type="text" name="name" placeholder="Your Full Name"
            value="<?php echo htmlspecialchars($_SESSION['user']); ?>" required>

        <input type="email" name="email" placeholder="Your Email" required>

        <input type="url" name="linkedin" placeholder="LinkedIn Profile URL" required>

        <input type="url" name="github" placeholder="GitHub Profile URL (optional)">

        <button type="submit">Apply Now</button>
    </form>

</div>

</body>
</html>