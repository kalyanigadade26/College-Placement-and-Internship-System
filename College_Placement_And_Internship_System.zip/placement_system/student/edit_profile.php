<?php
session_start();
include("../db.php");

if(!isset($_SESSION['user']) || $_SESSION['role'] != "student"){
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$stmt = $conn->prepare("SELECT * FROM users WHERE id=?");
$stmt->bindValue(1,$user_id);
$user = $stmt->execute()->fetchArray(SQLITE3_ASSOC);

if($_SERVER["REQUEST_METHOD"]=="POST"){

    $name = $_POST['name'];
    $email = $_POST['email'];
    $education = $_POST['education'];
    $skills = $_POST['skills'];

    $resumeName = $user['resume'];

    if(!empty($_FILES['resume']['name'])){
        if($_FILES['resume']['type']=="application/pdf"){
            $resumeName = time()."_".$_FILES['resume']['name'];
            move_uploaded_file($_FILES['resume']['tmp_name'],"../uploads/".$resumeName);
        }
    }

    $stmt = $conn->prepare("UPDATE users SET name=?, email=?, education=?, skills=?, resume=? WHERE id=?");
    $stmt->bindValue(1,$name);
    $stmt->bindValue(2,$email);
    $stmt->bindValue(3,$education);
    $stmt->bindValue(4,$skills);
    $stmt->bindValue(5,$resumeName);
    $stmt->bindValue(6,$user_id);

    if($stmt->execute()){
        $_SESSION['user']=$name;
        header("Location: profile.php");
        exit();
    } else {
        $error="Update failed!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Edit Profile</title>

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Segoe UI', sans-serif;
}

body{
    background:linear-gradient(135deg,#eef2ff,#e0e7ff);
}

/* NAVBAR */
.navbar{
    display:flex;
    justify-content:space-between;
    align-items:center;
    padding:18px 50px;
    background:#111;
    color:#fff;
}

.nav-links{
    display:flex;
    align-items:center;
}

.nav-links a{
    color:#fff;
    margin-left:25px;
    text-decoration:none;
    font-size:15px;
}

.nav-links .btn{
    background:#fff;
    color:#000 !important;
    padding:7px 14px;
    border-radius:6px;
}

/* CENTER */
.container{
    display:flex;
    justify-content:center;
    align-items:center;
    min-height:calc(100vh - 70px);
    padding:40px 20px;
}

/* CARD */
.card{
    background:#fff;
    padding:40px;
    width:450px;
    border-radius:16px;
    box-shadow:0 10px 25px rgba(0,0,0,0.08);
}

/* TITLE */
.card h2{
    text-align:center;
    margin-bottom:25px;
    font-size:26px;
}

/* INPUT */
input, textarea{
    width:100%;
    padding:12px;
    margin-bottom:15px;
    border:1px solid #ddd;
    border-radius:8px;
    font-size:14px;
    transition:0.2s;
}

input:focus, textarea:focus{
    border-color:#6366f1;
    outline:none;
    box-shadow:0 0 0 2px rgba(99,102,241,0.15);
}

/* FILE */
input[type="file"]{
    border:none;
}

/* BUTTON */
button{
    width:100%;
    padding:12px;
    background:#111;
    color:#fff;
    border:none;
    border-radius:8px;
    font-size:15px;
    cursor:pointer;
    transition:0.3s;
}

button:hover{
    background:#333;
}

/* ERROR */
.error{
    color:red;
    text-align:center;
    margin-bottom:10px;
}
</style>

</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
    <div>🎓 Student Panel</div>

    <div class="nav-links">
        <a href="../index.php">Home</a>
        <a href="../about.php">About</a>
        <a href="../contact.php">Contact</a>
        <a href="../feedback.php">Feedback</a>
        <a href="student_dashboard.php">Dashboard</a>
        <a href="../logout.php" class="btn">Logout</a>
    </div>
</div>

<!-- FORM -->
<div class="container">
<div class="card">

<h2>Edit Profile</h2>

<?php if(isset($error)) echo "<p class='error'>$error</p>"; ?>

<form method="post" enctype="multipart/form-data">

<input type="text" name="name" value="<?php echo htmlspecialchars($user['name']); ?>" required>

<input type="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>

<textarea name="education" placeholder="Education"><?php echo htmlspecialchars($user['education']); ?></textarea>

<textarea name="skills" placeholder="Skills"><?php echo htmlspecialchars($user['skills']); ?></textarea>

<label style="font-size:14px;">Upload Resume (PDF)</label>
<input type="file" name="resume">

<button>Save Changes</button>

</form>

</div>
</div>

</body>
</html>