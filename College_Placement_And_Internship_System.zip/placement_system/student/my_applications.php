<?php
session_start();
include("../db.php");

// Protect page
if(!isset($_SESSION['user']) || $_SESSION['role'] != "student") {
    header("Location: /placement_system/login.php");
    exit();
}

$user_name = $_SESSION['user']; // using name

// Fetch applications
$stmt = $conn->prepare("
SELECT jobs.title, jobs.company, jobs.location,
       applications.linkedin, applications.github
FROM applications
JOIN jobs ON applications.job_id = jobs.id
WHERE applications.student_name = ?
ORDER BY applications.rowid DESC
");

$stmt->bindValue(1, $user_name, SQLITE3_TEXT);
$result = $stmt->execute();
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>My Applications</title>

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Segoe UI', sans-serif;
}

body{
    background:linear-gradient(135deg,#eef2ff,#e0e7ff);
}

/* NAVBAR */
.navbar{
    display:flex;
    justify-content:space-between;
    align-items:center;
    padding:18px 50px;
    background:#111;
    color:#fff;
}

.nav-links{
    display:flex;
    align-items:center;
}

.nav-links a{
    color:#fff;
    margin-left:25px;
    text-decoration:none;
    font-size:15px;
}

.nav-links .btn{
    background:#fff;
    color:#000 !important;
    padding:7px 14px;
    border-radius:6px;
    font-weight:500;
}

/* CONTAINER */
.container{
    max-width:1100px;
    margin:60px auto;
    padding:0 20px;
}

/* TITLE */
.title{
    text-align:center;
    margin-bottom:30px;
}

.title h1{
    font-size:30px;
    color:#222;
}

/* TABLE BOX */
.table-box{
    background:#fff;
    padding:30px;
    border-radius:14px;
    box-shadow:0 10px 25px rgba(0,0,0,0.08);
}

/* TABLE */
table{
    width:100%;
    border-collapse:collapse;
}

th, td{
    padding:16px;
    text-align:left;
    border-bottom:1px solid #eee;
}

th{
    background:#111;
    color:#fff;
    font-weight:500;
}

tr:hover{
    background:#f8fafc;
}

/* LINKS */
a.link{
    color:#2563eb;
    text-decoration:none;
    font-weight:500;
}

a.link:hover{
    text-decoration:underline;
}

/* EMPTY */
.empty{
    text-align:center;
    padding:25px;
    color:#555;
}
</style>

</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
    <div>🎓 Student Panel</div>

    <div class="nav-links">
        <a href="/placement_system/index.php">Home</a>
        <a href="/placement_system/about.php">About</a>
        <a href="/placement_system/contact.php">Contact</a>
        <a href="/placement_system/feedback.php">Feedback</a>
        <a href="/placement_system/student/student_dashboard.php">Dashboard</a>
        <a href="/placement_system/logout.php" class="btn">Logout</a>
    </div>
</div>

<!-- CONTENT -->
<div class="container">

    <div class="title">
        <h1>My Applications</h1>
    </div>

    <div class="table-box">

        <?php 
        $hasData = false;
        while($row = $result->fetchArray(SQLITE3_ASSOC)) { 
            if(!$hasData){
                $hasData = true;
        ?>

        <table>
            <tr>
                <th>Job Title</th>
                <th>Company</th>
                <th>Location</th>
                <th>LinkedIn</th>
                <th>GitHub</th>
            </tr>

        <?php } ?>

            <tr>
                <td><?php echo htmlspecialchars($row['title']); ?></td>
                <td><?php echo htmlspecialchars($row['company']); ?></td>
                <td><?php echo htmlspecialchars($row['location']); ?></td>

                <td>
                    <a class="link" href="<?php echo htmlspecialchars($row['linkedin']); ?>" target="_blank">
                        View
                    </a>
                </td>

                <td>
                    <?php if(!empty($row['github'])) { ?>
                        <a class="link" href="<?php echo htmlspecialchars($row['github']); ?>" target="_blank">
                            View
                        </a>
                    <?php } else { echo "-"; } ?>
                </td>
            </tr>

        <?php } ?>

        <?php if($hasData) { ?>
            </table>
        <?php } else { ?>
            <p class="empty">You have not applied to any jobs yet.</p>
        <?php } ?>

    </div>

</div>

</body>
</html>