<?php
session_start();
include("../db.php");

if(!isset($_SESSION['user']) || $_SESSION['role'] != "student"){
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$stmt = $conn->prepare("SELECT * FROM users WHERE id=?");
$stmt->bindValue(1,$user_id);
$user = $stmt->execute()->fetchArray(SQLITE3_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
<title>My Profile</title>

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Segoe UI', sans-serif;
}

/* BODY */
body{
    background:linear-gradient(135deg,#eef2ff,#e0e7ff);
    min-height:100vh;
}

/* NAVBAR */
.navbar{
    display:flex;
    justify-content:space-between;
    align-items:center;
    padding:18px 50px;
    background:#111;
    color:#fff;
}

.nav-links{
    display:flex;
    align-items:center;
}

.nav-links a{
    color:#fff;
    margin-left:25px;
    text-decoration:none;
    font-size:15px;
}

.nav-links .btn{
    background:#fff;
    color:#000 !important;
    padding:7px 14px;
    border-radius:6px;
    font-weight:500;
}

/* CONTAINER */
.container{
    display:flex;
    justify-content:center;
    padding:60px 20px;
}

/* CARD */
.card{
    background:#fff;
    width:650px;
    padding:45px;
    border-radius:16px;
    box-shadow:0 10px 30px rgba(0,0,0,0.08);
}

/* TITLE */
.card h2{
    text-align:center;
    margin-bottom:35px;
    font-size:28px;
    color:#222;
}

/* PROFILE GRID */
.profile-grid{
    display:grid;
    grid-template-columns:180px 1fr;
    row-gap:18px;
    column-gap:20px;
    align-items:center;
}

/* LABEL */
.label{
    font-weight:600;
    color:#444;
}

/* VALUE */
.value{
    color:#111;
}

/* RESUME BUTTON */
.resume-btn{
    display:inline-block;
    padding:8px 14px;
    background:#111;
    color:#fff;
    text-decoration:none;
    border-radius:6px;
    font-size:14px;
}

/* EDIT BUTTON */
.edit-btn{
    display:block;
    text-align:center;
    margin-top:35px;
    padding:12px;
    background:#111;
    color:#fff;
    text-decoration:none;
    border-radius:8px;
    font-size:15px;
    transition:0.3s;
}

.edit-btn:hover{
    background:#333;
}
</style>

</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
    <div>🎓 Student Panel</div>

    <div class="nav-links">
        <a href="../index.php">Home</a>
        <a href="../about.php">About</a>
        <a href="../contact.php">Contact</a>
        <a href="../feedback.php">Feedback</a>
        <a href="student_dashboard.php">Dashboard</a>
        <a href="../logout.php" class="btn">Logout</a>
    </div>
</div>

<!-- PROFILE -->
<div class="container">
<div class="card">

<h2>My Profile</h2>

<div class="profile-grid">
    <div class="label">Name</div>
    <div class="value"><?php echo htmlspecialchars($user['name']); ?></div>

    <div class="label">Email</div>
    <div class="value"><?php echo htmlspecialchars($user['email']); ?></div>

    <div class="label">Education</div>
    <div class="value"><?php echo !empty($user['education']) ? htmlspecialchars($user['education']) : "Not added"; ?></div>

    <div class="label">Skills</div>
    <div class="value"><?php echo !empty($user['skills']) ? htmlspecialchars($user['skills']) : "Not added"; ?></div>

    <div class="label">Resume</div>
    <div class="value">
        <?php if(!empty($user['resume'])) { ?>
            <a href="../uploads/<?php echo htmlspecialchars($user['resume']); ?>" target="_blank" class="resume-btn">View Resume</a>
        <?php } else { ?>
            Not uploaded
        <?php } ?>
    </div>
</div>

<a href="edit_profile.php" class="edit-btn">Edit Profile</a>

</div>
</div>

</body>
</html>