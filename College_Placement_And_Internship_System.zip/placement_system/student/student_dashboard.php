<?php
session_start();

// Protect page
if(!isset($_SESSION['user']) || $_SESSION['role'] != "student") {
    header("Location: /placement_system/login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Student Dashboard</title>

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:Arial, sans-serif;
}

/* FULL SCREEN */
body{
    background:linear-gradient(135deg,#eef2ff,#e0e7ff);
    min-height:100vh;
}

/* NAVBAR */
.navbar{
    display:flex;
    justify-content:space-between;
    align-items:center;
    padding:15px 40px;
    background:#111;
    color:#fff;
}

.nav-links a{
    color:#fff;
    margin-left:20px;
    text-decoration:none;
}

.nav-links .btn{
    background:#fff;
    color:#000 !important;
    padding:6px 12px;
    border-radius:5px;
}

/* DASHBOARD CONTAINER */
.dashboard{
    padding:40px;
}

/* WELCOME */
.welcome{
    text-align:center;
    margin-bottom:50px;
}

.welcome h1{
    font-size:32px;
    margin-bottom:10px;
}

.welcome p{
    color:#555;
}

/* CARDS GRID */
.cards{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(250px,1fr));
    gap:30px;
}

/* CARD */
.card{
    background:#fff;
    padding:30px;
    border-radius:12px;
    text-align:center;
    box-shadow:0 5px 15px rgba(0,0,0,0.1);
    transition:0.3s;
}

.card:hover{
    transform:translateY(-8px);
}

/* CARD TITLE */
.card h2{
    margin-bottom:10px;
}

/* CARD TEXT */
.card p{
    color:#555;
    margin-bottom:20px;
}

/* BUTTON */
.card a{
    display:inline-block;
    padding:10px 15px;
    background:#111;
    color:#fff;
    text-decoration:none;
    border-radius:6px;
}
</style>

</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
    <div>🎓 Student Panel</div>

    <div class="nav-links">
        <a href="/placement_system/index.php">Home</a>
        <a href="/placement_system/about.php">About</a>
        <a href="/placement_system/contact.php">Contact</a>
        <a href="/placement_system/feedback.php">Feedback</a> <!-- ✅ ADDED -->
        <a href="/placement_system/student/student_dashboard.php">Dashboard</a>
        <a href="/placement_system/logout.php" class="btn">Logout</a>
    </div>
</div>

<!-- DASHBOARD -->
<div class="dashboard">

    <!-- WELCOME -->
    <div class="welcome">
        <h1>Welcome, <?php echo $_SESSION['user']; ?></h1>
        <p>Explore internships and placement opportunities</p>
    </div>

    <!-- CARDS -->
    <div class="cards">

        <!-- VIEW JOBS -->
        <div class="card">
            <h2>💼 View Jobs</h2>
            <p>Browse all available placement and internship opportunities.</p>
            <a href="/placement_system/student/view_jobs.php">View Jobs</a>
        </div>

        <!-- MY APPLICATIONS -->
        <div class="card">
            <h2>📄 My Applications</h2>
            <p>Track jobs you have applied for.</p>
            <a href="/placement_system/student/my_applications.php">View Applications</a>
        </div>

        <!-- PROFILE -->
        <div class="card">
            <h2>👤 Profile</h2>
            <p>Manage your personal details and resume.</p>
            <a href="/placement_system/student/profile.php">View Profile</a>
        </div>

    </div>

</div>

</body>
</html>