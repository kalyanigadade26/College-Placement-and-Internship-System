<?php
session_start();
include("../db.php");

// Protect page
if(!isset($_SESSION['user']) || $_SESSION['role'] != "student") {
    header("Location: ../login.php");
    exit();
}

// Fetch jobs
$jobs = $conn->query("SELECT * FROM jobs WHERE title != '' AND company != '' AND location != '' ORDER BY id DESC");
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>View Jobs</title>

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:Arial, sans-serif;
}

/* FULL SCREEN */
body{
    background:linear-gradient(135deg,#eef2ff,#e0e7ff);
    min-height:100vh;
}

/* NAVBAR */
.navbar{
    display:flex;
    justify-content:space-between;
    align-items:center;
    padding:15px 40px;
    background:#111;
    color:#fff;
}

.nav-links a{
    color:#fff;
    margin-left:20px;
    text-decoration:none;
}

.nav-links .btn{
    background:#fff;
    color:#000 !important;
    padding:6px 12px;
    border-radius:5px;
}

/* CONTAINER */
.container{
    padding:40px;
}

/* TITLE */
.title{
    text-align:center;
    margin-bottom:40px;
}

.title h1{
    font-size:30px;
}

/* GRID */
.jobs{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(280px,1fr));
    gap:25px;
}

/* CARD */
.job-card{
    background:#fff;
    padding:25px;
    border-radius:12px;
    box-shadow:0 5px 15px rgba(0,0,0,0.1);
    transition:0.3s;
}

.job-card:hover{
    transform:translateY(-8px);
}

/* TEXT */
.job-card h2{
    margin-bottom:10px;
}

.job-card p{
    color:#555;
    margin-bottom:10px;
}

/* BUTTON */
.job-card a{
    display:inline-block;
    margin-top:10px;
    padding:8px 12px;
    background:#111;
    color:#fff;
    text-decoration:none;
    border-radius:6px;
}
</style>

</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
    <div>🎓 Student Panel</div>

    <div class="nav-links">
        <a href="../index.php">Home</a>
        <a href="../about.php">About</a>
        <a href="../contact.php">Contact</a>
        <a href="../feedback.php">Feedback</a> <!-- ✅ ADDED -->
        <a href="student_dashboard.php">Dashboard</a>
        <a href="../logout.php" class="btn">Logout</a>
    </div>
</div>

<!-- JOBS -->
<div class="container">

    <div class="title">
        <h1>Available Jobs & Internships</h1>
    </div>

    <div class="jobs">

        <?php while($job = $jobs->fetchArray()) { 
            if(empty($job['title']) || empty($job['company']) || empty($job['location'])) {
                continue;
            }
        ?>

            <div class="job-card">
                <h2><?php echo htmlspecialchars($job['title']); ?></h2>
                <p><b>Company:</b> <?php echo htmlspecialchars($job['company']); ?></p>
                <p><b>Location:</b> <?php echo htmlspecialchars($job['location']); ?></p>
                <p><?php echo nl2br(htmlspecialchars($job['description'])); ?></p>

                <a href="apply_job.php?id=<?php echo $job['id']; ?>">Apply</a>
            </div>

        <?php } ?>

    </div>

</div>

</body>
</html>